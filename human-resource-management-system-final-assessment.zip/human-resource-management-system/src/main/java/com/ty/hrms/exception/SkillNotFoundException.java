package com.ty.hrms.exception;
public class SkillNotFoundException extends RuntimeException{
	public SkillNotFoundException(String message) {
		super(message);
	}
}
