package com.ty.hrms.service;

import com.ty.hrms.dto.RegisterDTO;

public interface HRMSService {

	String register(RegisterDTO registerDTO);

}
