package com.ty.hrms.exception;
public class ProgramNotFoundException extends RuntimeException{
	public ProgramNotFoundException(String message) {
		super(message);
	}
}
