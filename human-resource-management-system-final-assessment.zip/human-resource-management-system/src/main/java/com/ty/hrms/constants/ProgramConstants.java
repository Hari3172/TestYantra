package com.ty.hrms.constants;

public class ProgramConstants {
	public static final String PROGRAM_NOT_FOUND = "Role could not found!";
}
