package com.ty.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.hrms.entity.TrainingProgram;

public interface TrainingProgramRepository extends JpaRepository<TrainingProgram, Integer>{

}
