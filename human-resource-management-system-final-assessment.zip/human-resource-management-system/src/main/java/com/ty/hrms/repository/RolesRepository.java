package com.ty.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.hrms.entity.Roles;

public interface RolesRepository extends JpaRepository<Roles, String>{

}
