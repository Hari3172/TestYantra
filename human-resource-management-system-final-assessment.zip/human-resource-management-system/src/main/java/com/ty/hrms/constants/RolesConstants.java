package com.ty.hrms.constants;

public class RolesConstants {
	public static final String ROLE_NOT_FOUND = "Role could not found!";
}
